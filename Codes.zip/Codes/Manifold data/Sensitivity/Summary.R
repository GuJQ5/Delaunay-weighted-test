Resultss<-NULL
for(a in 1:9)
{
  XX<-NULL
  for(b in 1:10)
  {
    if(file.exists(paste0(a,"_",b,".csv")))
    {
      XX<-c(XX,read.csv(paste0(a,"_",b,".csv"))[,2])
    }
    print(c(a,b))
  }
  Resultss<-rbind(Resultss,c(mean(XX<=0.01),mean(XX<=0.05),mean(XX<=0.1)))
  
}

Resultss<-rbind(c(46.2,74,84.4)/100,NA,Resultss,NA,c(47.2,71.8,81.0)/100)
Labelss<-c("Known Manifold",expression("Fixed "~hat(d)==6),
           expression("Fixed "~hat(d)==7),
           expression("Fixed "~hat(d)==8),
           expression("Fixed "~hat(d)==9),
           expression("Fixed "~hat(d)==10),
           expression("Fixed "~hat(d)==11),
           expression("Fixed "~hat(d)==12),
           expression("Fixed "~hat(d)==13),
           expression("Fixed "~hat(d)==14),expression("Estimated "~hat(d)))
png("Sensitivity1.png",480,480)
par(mar=c(5,10,1,1))
plot(0,0,type='n',xlim=c(0,1),ylim=c(13,0),xaxt="n",yaxt="n",xlab="",ylab="",axes=F,yaxs="i",xaxs="i")
axis(1,0:5/5,0:5/5,cex.axis=1.5)
mtext("Power",1,3,cex=2)
axis(2,c(-1,14),rep("",2))
rrr<-c(1,3:11,13)
# Labelss<-c("Known Manifold",paste0("Fixed d=",6:14),expression("Estimated "~hat(d)))
for(a in 1:11)
{
  # colss<-rgb((11-a)/10*0.6+0.4,0.7-(11-a)/10*0.5,1-(11-a)/10,0.8)
  colss<-c("red","purple","blue")[(a>1)+(a>10)+1]
  rect(0,rrr[a]-0.1,Resultss[rrr[a],1],rrr[a]-0.9,col=colss,border = colss)
  mtext(Labelss[a],side=2,line=1,at=rrr[a]-0.5,cex=1.5,las=2)
}
dev.off()

png("Sensitivity2.png",480,480)
par(mar=c(5,10,1,1))
plot(0,0,type='n',xlim=c(0,1),ylim=c(13,0),xaxt="n",yaxt="n",xlab="",ylab="",axes=F,yaxs="i",xaxs="i")
axis(1,0:5/5,0:5/5,cex.axis=1.5)
mtext("Power",1,3,cex=2)
axis(2,c(-1,14),rep("",2))
rrr<-c(1,3:11,13)

for(a in 1:11)
{
  # colss<-rgb((11-a)/10*0.6+0.4,0.7-(11-a)/10*0.5,1-(11-a)/10,0.8)
  colss<-c("red","purple","blue")[(a>1)+(a>10)+1]
  rect(0,rrr[a]-0.1,Resultss[rrr[a],2],rrr[a]-0.9,col=colss,border = colss)
  mtext(Labelss[a],side=2,line=1,at=rrr[a]-0.5,cex=1.5,las=2)
}
dev.off()

png("Sensitivity3.png",480,480)
par(mar=c(5,10,1,1))
plot(0,0,type='n',xlim=c(0,1),ylim=c(13,0),xaxt="n",yaxt="n",xlab="",ylab="",axes=F,yaxs="i",xaxs="i")
axis(1,0:5/5,0:5/5,cex.axis=1.5)
mtext("Power",1,3,cex=2)
axis(2,c(-1,14),rep("",2))
rrr<-c(1,3:11,13)
# Labelss<-c("Known Manifold",paste0("Fixed d=",6:14),expression("Estimated "~hat(d)))
for(a in 1:11)
{
  # colss<-rgb((11-a)/10*0.6+0.4,0.7-(11-a)/10*0.5,1-(11-a)/10,0.8)
  colss<-c("red","purple","blue")[(a>1)+(a>10)+1]
  rect(0,rrr[a]-0.1,Resultss[rrr[a],3],rrr[a]-0.9,col=colss,border = colss)
  mtext(Labelss[a],side=2,line=1,at=rrr[a]-0.5,cex=1.5,las=2)
}
dev.off()