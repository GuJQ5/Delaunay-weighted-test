Resultss<-NULL
TT<-NULL

XX<-NULL
for(Pai in 1:20)
{
  XX<-rbind(XX,read.csv(paste0("Null_",Pai,".csv")))
}
d_hat<-XX[,1]
PP<-as.matrix(XX[,-1])
range(d_hat)
mean(d_hat)
# d_hat[d_hat>=6]<-6

Resultss<-rbind(Resultss,colMeans(PP[,3:13-1]<=0.01),colMeans(PP[,3:13-1]<=0.05),colMeans(PP[,3:13-1]<=0.1))
TT<-rbind(TT,colMeans(PP[,15:19-1]),apply(PP[,15:19-1],2,sd))

XX<-NULL
for(Pai in 1:20)
{
  XX<-rbind(XX,read.csv(paste0("Location_",Pai,".csv")))
}
d_hat<-XX[,1]
PP<-as.matrix(XX[,-1])
range(d_hat)
mean(d_hat)
# d_hat[d_hat>=6]<-6

Resultss<-rbind(Resultss,colMeans(PP[,3:13-1]<=0.01),colMeans(PP[,3:13-1]<=0.05),colMeans(PP[,3:13-1]<=0.1))
TT<-rbind(TT,colMeans(PP[,15:19-1]),apply(PP[,15:19-1],2,sd))

XX<-NULL
for(Pai in 1:20)
{
  XX<-rbind(XX,read.csv(paste0("Direction_",Pai,".csv")))
}
d_hat<-XX[,1]
PP<-as.matrix(XX[,-1])
range(d_hat)
mean(d_hat)
# d_hat[d_hat>=6]<-6

Resultss<-rbind(Resultss,colMeans(PP[,3:13-1]<=0.01),colMeans(PP[,3:13-1]<=0.05),colMeans(PP[,3:13-1]<=0.1))
TT<-rbind(TT,colMeans(PP[,15:19-1]),apply(PP[,15:19-1],2,sd))

rownames(Resultss)<-paste0(rep(c("Null","Location","Direction"),each=3),"_",rep(c("0.01","0.05","0.10"),3))
colnames(Resultss)<-c("DW_original","DW_d","DW_dhat","k-NN","k-MST","Kernel (True)","Kernel (Estimated)","e-distance","Covariance","Regression","Regression2")
# colMeans(PP)
write.table(round(cbind(t(Resultss[1:3,c(1,2,3,6,7,10,4,5,8,9)]),NA,t(Resultss[4:6,c(1,2,3,6,7,10,4,5,8,9)]),NA,t(Resultss[7:9,c(1,2,3,6,7,10,4,5,8,9)]))*100,1),"Manifold1.txt",sep="&")

round(cbind(t(Resultss[1:3,]),NA,t(Resultss[4:6,]),NA,t(Resultss[7:9,]))*100,1)