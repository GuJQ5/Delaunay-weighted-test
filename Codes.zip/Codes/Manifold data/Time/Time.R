args = commandArgs(TRUE)
Pai = as.numeric(args[1])
Pai_a<-ceiling(Pai/20)
Pai<-Pai-(Pai_a-1)*20
Pai_b<-ceiling(Pai/4)
Pai_c<-Pai-(Pai_b-1)*4


library(mvtnorm)
source("/home/j/jiaqigu/DW/Manifold/Time/Existing.R")
source("/home/j/jiaqigu/DW/Manifold/Time/Embedding_function.R")
source("/home/j/jiaqigu/DW/Manifold/Time/Function.R")
# source("Existing.R")
# source("Embedding_function.R")
# source("Function.R")

# Setting<-c("Null","Location","Direction")[Pai_a]
n1<-125*2^(Pai_a-1)
n0<-125*2^(Pai_a-1)
n<-n1+n0
D<-50*Pai_c
d1<-Pai_b
d2<-Pai_b
d<-d1+d2
B<-1000
rangess<-8
n_iter<-100
aa<-1
bb<-pi


##############################################
P_value_record<-NULL
kai<-0
if(file.exists(paste0("/home/j/jiaqigu/DW/Manifold/Time/",Pai_a,"_",Pai_b,"_",Pai_c,".csv")))
{
P_value_record<-as.matrix(read.csv(paste0("/home/j/jiaqigu/DW/Manifold/Time/",Pai_a,"_",Pai_b,"_",Pai_c,".csv")))
kai<-(nrow(P_value_record))
}
if(kai<n_iter)
{
  for(iter in (kai+1):n_iter)
  {
    TT0<-Sys.time()
    {
      Hai<-matrix(0,d,d)
      kk<-sample(d)
      diag(Hai)<-0
      # for(a in 1:(d/2))
      # {
      #   Hai[kk[2*a-1],kk[2*a]]<-0.12*(Pai_a==3)
      #   Hai[kk[2*a],kk[2*a-1]]<-0.12*(Pai_a==3)
      # }
      iso_zx<-rmvnorm(n1,rep(1,d)*0,diag(1,d)+Hai)
      iso_zy<-rmvnorm(n0,-rep(1,d)*0,diag(1,d)-Hai)
      iso_zz<-rbind(iso_zx,iso_zy)
      zz<-iso_zz
      zz[,1:d1]<-0
      mm<-(max(abs(iso_zz)[,1:d1]))
      xbase<-(1:1000-0.5)/1000
      xxx<-xbase
      while(sum(0.001*sqrt(aa^2+aa^2*bb^2*xxx^2))<mm)
      {
        xbase<-xbase+1
        xxx<-c(xxx,xbase)
      }
      ddd<-0.001*sqrt(aa^2+aa^2*bb^2*xxx^2)
      lll<-c(0,cumsum(ddd))
      for(i in 1:length(xxx))
      {
        bili<-(abs(iso_zz[,1:d1])-lll[i])/(ddd[i])
        zz[,1:d1]<-zz[,1:d1]+(bili>=0)*(bili<1)*(i-1+bili)/1000
      }
      zz[,1:d1]<-zz[,1:d1]*sign(iso_zz[,1:d1])
      
      xx<-cbind(aa*zz[,1:d1]*cos(bb*zz[,1:d1]),aa*zz[,1:d1]*sin(bb*zz[,1:d1])*sign(zz[,1:d1]))
      xx<-cbind(xx,zz[,-(1:d1)])
      Q<-matrix(rnorm((2*d1+d2)*D),D)
      Q[,1]<-Q[,1]/sqrt(sum(Q[,1]^2))
      for(j in 2:(2*d1+d2))
      {
        Q[,j]<-Q[,j]-Q[,1:(j-1)]%*%(t(Q[,1:(j-1)])%*%Q[,j])
        Q[,j]<-Q[,j]/sqrt(sum(Q[,j]^2))
      }
      Z<-xx%*%t(Q)
      Delta<-c(rep(1,n1),rep(0,n0))
      Hey<-sample(n)
      iso_zz<-iso_zz[Hey,]
      zz<-zz[Hey,]
      Z<-Z[Hey,]
      Delta<-Delta[Hey]
    }
    
    
    T_record_iter<-NULL
    {
      T_record_0<-Sys.time()
      d_hat<-Intrinsic_dimension_estimate(Z)
      T_record_1<-Sys.time()
      T_record_iter<-c(T_record_iter,difftime(T_record_1, T_record_0, units = "secs"))
      
      T_record_0<-Sys.time()
      k<-4*d_hat
      Dist_Z<-Robust_geodesic_distance(Z,k)
      T_record_1<-Sys.time()
      T_record_iter<-c(T_record_iter,difftime(T_record_1, T_record_0, units = "secs"))
      
      ### Estimated d
      T_record_0<-Sys.time()
      Z_hat_d_hat<-cmdscale(Dist_Z,k=d_hat)
      T_record_1<-Sys.time()
      T_record_iter<-c(T_record_iter,difftime(T_record_1, T_record_0, units = "secs"))
      
      T_record_0<-Sys.time()
      W_d_hat<-DWM(Z_hat_d_hat,eta=15)
      T_record_1<-Sys.time()
      T_record_iter<-c(T_record_iter,difftime(T_record_1, T_record_0, units = "secs"))
      
      T_record_0<-Sys.time()
      T_d_hat<-sum(W_d_hat[Delta==1,Delta==1])+sum(W_d_hat[Delta==0,Delta==0])
      T_perm_d_hat<-rep(0,B)
      for(b in 1:B)
      {
        Delta_perm<-Delta[sample(n)]
        T_perm_d_hat[b]<-sum(W_d_hat[Delta_perm==1,Delta_perm==1])+sum(W_d_hat[Delta_perm==0,Delta_perm==0])
      }
      P_DW_d_hat<-(1+sum(T_perm_d_hat>=T_d_hat))/(1+B)
      T_record_1<-Sys.time()
      T_record_iter<-c(T_record_iter,difftime(T_record_1, T_record_0, units = "secs"))
    }
    
    T_record_0<-Sys.time()
    P_kNN<-Hall2002(Z,Delta,B=B,k=d_hat+1)
    T_record_1<-Sys.time()
    T_record_iter<-c(T_record_iter,difftime(T_record_1, T_record_0, units = "secs"))
    
    T_record_0<-Sys.time()
    P_kMST<-Chen2017(Z,Delta,k=d_hat+1)
    T_record_1<-Sys.time()
    T_record_iter<-c(T_record_iter,difftime(T_record_1, T_record_0, units = "secs"))
    
    T_record_0<-Sys.time()
    bw<-sqrt(sum(apply(Z,2,var)))*n^(-1/(d_hat+2))
    P_kernel_e<-Cheng2021(Z,Delta,B=B,bw=bw)
    T_record_1<-Sys.time()
    T_record_iter<-c(T_record_iter,difftime(T_record_1, T_record_0, units = "secs"))
    
    T_record_0<-Sys.time()
    P_euclidean<-Szekely2004(Z,Delta,B=B)
    T_record_1<-Sys.time()
    T_record_iter<-c(T_record_iter,difftime(T_record_1, T_record_0, units = "secs"))
    
    T_record_0<-Sys.time()
    P_cov<-Cai2013(Z,Delta)
    T_record_1<-Sys.time()
    T_record_iter<-c(T_record_iter,difftime(T_record_1, T_record_0, units = "secs"))
    
    T_record_0<-Sys.time()
    k_xuan<-ceiling(5*n^(2/(2+d_hat)))
    P_regression<-Kim2019_new(Z,Delta,B=B,k=k_xuan)
    T_record_1<-Sys.time()
    T_record_iter<-c(T_record_iter,difftime(T_record_1, T_record_0, units = "secs"))
    
    T_record_0<-Sys.time()
    P_euclidean<-Szekely2004(Z,Delta,B=B)
    T_record_1<-Sys.time()
    T_record_iter<-c(T_record_iter,difftime(T_record_1, T_record_0, units = "secs"))
    
    T_record_0<-Sys.time()
    P_cov<-Cai2013(Z,Delta)
    T_record_1<-Sys.time()
    T_record_iter<-c(T_record_iter,difftime(T_record_1, T_record_0, units = "secs"))
    
    T_record_0<-Sys.time()
    k_xuan<-ceiling(5*n^(2/(2+d_hat)))
    P_regression<-Kim2019_new(Z,Delta,B=B,k=k_xuan)
    T_record_1<-Sys.time()
    T_record_iter<-c(T_record_iter,difftime(T_record_1, T_record_0, units = "secs"))
    
    P_value_record<-rbind(P_value_record,c(d,T_record_iter))
    TT1<-Sys.time()
    print(c(Pai_a,Pai_b,iter))
    print(TT1-TT0)

    
    
    write.csv(P_value_record,paste0("/home/j/jiaqigu/DW/Manifold/Time/",Pai_a,"_",Pai_b,"_",Pai_c,".csv"),row.names = F)
  }
}