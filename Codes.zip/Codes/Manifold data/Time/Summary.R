Resultss<-NULL
SD_Resultss<-NULL
for(Pai_a in 1:3)
{
  for(Pai_b in 1:5)
  {
    for(Pai_c in 1:4)
    {
      
      n<-125*2^(Pai_a)
      D<-50*Pai_c
      d<-Pai_b*2
      
      XX<-read.csv(paste0(Pai_a,"_",Pai_b,"_",Pai_c,".csv"))[,-1]
      
      Resultss<-rbind(Resultss,c(n,d,D,colMeans(XX)))
      SD_Resultss<-rbind(SD_Resultss,c(n,d,D,apply(XX,2,sd)))
    }
  }
}
colnames(Resultss)<-c("n","d","D","Estimating d","Geodesic distance estimation","MDS","DW","Permutation test","k-NN","k-MST","Kernel","e-distance","Covariance","Regression")

Resultss<-rbind(Resultss[c(18,38,58),],Resultss[c(42,46,50,54,58),],Resultss[c(57,58,59,60),])
Resultss<-cbind(Resultss[,1:8],rowSums(Resultss[,4:8]),Resultss[,9:14])

SD_Resultss<-rbind(SD_Resultss[c(18,38,58),],SD_Resultss[c(42,46,50,54,58),],SD_Resultss[c(57,58,59,60),])
SD_Resultss<-cbind(SD_Resultss[,1:8],rowSums(SD_Resultss[,4:8]),SD_Resultss[,9:14])

HHH<-matrix(NA,nrow = nrow(Resultss),ncol=ncol(Resultss))
for(i in 1:nrow(Resultss))
{
  for(j in 1:3)
  {
    HHH[i,j]<-as.character(Resultss[i,j])
  }
}
for(i in 1:nrow(Resultss))
{
  for(j in 4:ncol(Resultss))
  {
    HHH[i,j]<-paste0(round(Resultss[i,j],2),"(",round(SD_Resultss[i,j],2),")")
  }
}
HHH<-t(HHH)
rownames(HHH)<-colnames(Resultss)
HHH<-rbind(cbind(HHH[,1:3],NA,HHH[,9:12]),cbind(HHH[,4:8],NA,NA,NA))
HHH<-cbind(HHH,"\\\\")
write.table(HHH,"Time.txt",sep="&")
