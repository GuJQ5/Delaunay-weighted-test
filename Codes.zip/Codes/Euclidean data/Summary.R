for(Pai_a in 1:3)
{
  YYY<-c("Delaunay weighted","$k$-NN","$k$-MST","Kernel","$e$-distance","Covariance","Regression")
  RR<-NULL
  Hai<-NULL
  for(Pai_b in 1:3)
  {
    Setting<-c("Null","Location","Direction")[Pai_a]
    n1<-c(50,100,100,50,100,100)[Pai_b]
    n0<-c(50,50,100,50,50,100)[Pai_b]
    d<-c(20,20,20,50,50,50)[Pai_b]
    P_value_record<-NULL
    for(Pai_c in 1:5)
    {
      P_value_record<-rbind(P_value_record,read.csv(paste0(Setting,"_",Pai_b,"_",Pai_c,".csv")))
    }
    Hai<-cbind(Hai,(100*round(colMeans(P_value_record<=0.01),3)),(100*round(colMeans(P_value_record<=0.05),3)),(100*round(colMeans(P_value_record<=0.10),3)),NA)
  }
  
  RR<-rbind(RR,Hai)
  Hai<-NULL
  for(Pai_b in 4:6)
  {
    Setting<-c("Null","Location","Direction")[Pai_a]
    n1<-c(50,100,100,50,100,100)[Pai_b]
    n0<-c(50,50,100,50,50,100)[Pai_b]
    d<-c(20,20,20,50,50,50)[Pai_b]
    P_value_record<-NULL
    for(Pai_c in 1:5)
    {
      P_value_record<-rbind(P_value_record,read.csv(paste0(Setting,"_",Pai_b,"_",Pai_c,".csv")))
    }
    Hai<-cbind(Hai,(100*round(colMeans(P_value_record<=0.01),3)),(100*round(colMeans(P_value_record<=0.05),3)),(100*round(colMeans(P_value_record<=0.10),3)),NA)
  }
  RR<-rbind(RR,Hai)
  if(Pai_a==1)
  {RR<-data.frame(rep(YYY,2),RR)}
  if(Pai_a!=1)
  {
    RR<-data.frame(rep("",nrow(RR)),rep(YYY,2),RR)
  }
  write.table(RR,paste0(Setting,".txt"),sep="&",row.names = F)
}