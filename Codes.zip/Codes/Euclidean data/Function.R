# Inverse Stereographic projection
Inverse_Stereographic_projection<-function(Z,p,r)
{
  d<-ncol(Z)
  if(length(p)!=d)
  {
    print("Invaild input.")
  }
  else
  {
    Z_central<-t(t(Z)-p)
    d2_Central<-rowSums(Z_central^2)
    Z_project<-cbind(2*Z_central*(r^2)/(r^2+d2_Central),2*r*d2_Central/(r^2+d2_Central)-r)
  }
  return(Z_project)
}

# Generate seed simplex on sphere
Seed_simplex_S<-function(Z_project,p_project) 
{
  # Data dimension
  n<-nrow(Z_project)
  d<-ncol(Z_project)
  if(((length(p_project)!=d)+(n<=d))!=0)
  {
    print("Invalid input.")
  }
  else
  {
    All_index<-1:n
    # Find the closest point: s1
    Dist_all<-colSums((t(Z_project[All_index,])-p_project)^2)
    vertices<-which.min(Dist_all)
    All_index<-setdiff(All_index,vertices)
    
    # Find the closet point to s1: s2
    Dist_all<-colSums((t(Z_project[All_index,])-Z_project[vertices,])^2)
    vertices<-c(vertices,All_index[which.min(Dist_all)])
    All_index<-setdiff(All_index,vertices)
    
    A_base<-matrix(Z_project[vertices[2],]-Z_project[vertices[1],],nrow = 1)
    b_base<-0.5*sum((Z_project[vertices[2],]-Z_project[vertices[1],])^2)
    
    
    for(j in 2:(d-1))
    {
      r_min<-Inf
      index<-NULL
      
      for(i in All_index)
      {
        A<-rbind(A_base,Z_project[i,]-Z_project[vertices[1],])
        b<-c(b_base,0.5*sum((Z_project[i,]-Z_project[vertices[1],])^2))
        
        Z_project_star<-t(A)%*%solve(A%*%t(A))%*%b
        if(sum(Z_project_star^2)<r_min)
        {
          r_min<-sum(Z_project_star^2)
          index<-i
        }
      }
      vertices<-c(vertices,index)
      All_index<-setdiff(All_index,index)
      A_base<-rbind(A_base,Z_project[index,]-Z_project[vertices[1],])
      b_base<-c(b_base,0.5*sum((Z_project[index,]-Z_project[vertices[1],])^2))
    }
    return(vertices)
  }
}

# Generate target Delaunay simplex on sphere
Find_simplex_S<-function(Z_project,p_project)
{
  n<-nrow(Z_project)
  d<-ncol(Z_project)
  if(((length(p_project)!=d)+(n<=d))!=0)
  {
    print("Invalid input.")
  }
  else
  {
    Simplex_set<-matrix(Seed_simplex_S(Z_project,p_project),ncol=d)
    Weight_set<-NULL
    Exploring<-0
    conditions<-0
    
    while(Exploring<nrow(Simplex_set))
    {
      Exploring<-Exploring+1
      S_current<-Simplex_set[Exploring,]
      Weighting<-solve((t(Z_project[S_current,])),p_project)
      if(prod(Weighting>0)==1)
      {
        conditions<-1
        break
      }else
      {
        Weight_set<-rbind(Weight_set,Weighting)
        cut_index<-which.min(Weighting)
        # cut_index<-which.min(Weighting)
        for(i in cut_index)
        {
          Facet<-S_current[-i]
          A_base<-t(t(Z_project)[,Facet[-1]]-Z_project[Facet[1],])
          # buchong<-t(t(Z_project)[,Facet[-1]]+Z_project[Facet[1],])
          b_base<-0.5*rowSums((A_base)^2)
          H<--t(A_base)%*%solve(A_base%*%t(A_base))%*%A_base
          diag(H)<-diag(H)+1
          
          p_s1<-Z_project[S_current[i],]-Z_project[Facet[1],]
          direction<-(H%*%p_s1)[,1]
          direction<-direction/sqrt(sum(direction^2))
          
          candidate_index<-setdiff(1:n,Facet)
          direction_all<-t(H%*%(t(Z_project)[,candidate_index]-Z_project[Facet[1],]))
          direction_all<-direction_all/sqrt(rowSums(direction_all^2))
          
          chabie<-(direction_all%*%direction)[,1]
          
          index<-candidate_index[which.min(chabie)]
          candidate_triangle<-c(Facet,index)
          
          aa<-0*Simplex_set
          for(wa in candidate_triangle)
          {
            aa<-aa+(Simplex_set==wa)
          }
          if(min(rowSums(1-aa))>0)
          {Simplex_set<-rbind(Simplex_set,candidate_triangle)}
        }
      }
      # print(c(S_current,conditions))
      # print(Simplex_set)
    }
    return(S_current)
  }
}

# Augment index for facet on convex hull
Augment_index<-function(Z,current_index) 
{
  # Data dimension
  n<-nrow(Z)
  d<-ncol(Z)
  if(((n<=d))!=0)
  {
    print("Invalid input.")
  }
  else
  {
    All_index<-setdiff(1:n,current_index)
    A_base<-t(t(Z)[,current_index[-1]]-Z[current_index[1],])
    buchong<-t(t(Z)[,current_index[-1]]+Z[current_index[1],])
    b_base<-0.5*rowSums((A_base)*buchong)
    
    # index<-All_index[1]
    
    
    while(length(All_index)>1)
    {
      index<-All_index[1]
      All_index<-c(All_index[-1],index)
      
      A<-rbind(A_base,Z[index,]-Z[current_index[1],])
      b<-c(b_base,0.5*sum((Z[index,]^2-Z[current_index[1],]^2)))
      
      Z_star<-(t(A)%*%solve(A%*%t(A))%*%b)[,1]
      
      r_current<-sum((Z_star-Z[index,])^2)
      r_other<-colSums((t(Z[All_index,])-Z_star)^2)
      
      All_index<-All_index[r_other<=r_current]
    }
    vertices<-c(current_index,All_index)
    return(vertices)
  }
}

# Compute the Delaunay weight
Weighting<-function(Z,p)
{
  # Data dimension
  n<-nrow(Z)
  d<-ncol(Z)
  if(((length(p)!=d)+((n-1)!=d))!=0)
  {
    print("Invalid input.")
  }
  else
  {
    w<-rep(0,n)
    positive_index<-1:n
    A<-t(Z)[,positive_index[-1]]-Z[positive_index[1],]
    b<-p-Z[positive_index[1],]
    w[positive_index[-1]]<-solve(t(A)%*%(A))%*%t(A)%*%b
    w[positive_index[1]]<-1-sum(w[positive_index[-1]])
    
    while(min(w)<0)
    {
      # negative_index_candidate<-
      positive_index<-setdiff(positive_index,which.min(w))
      w<-rep(0,n)
      if(length(positive_index)==1)
      {
        w[positive_index]<-1
      }else
      {
        A<-t(Z)[,positive_index[-1]]-Z[positive_index[1],]
        b<-p-Z[positive_index[1],]
        w[positive_index[-1]]<-solve(t(A)%*%(A))%*%t(A)%*%b
        w[positive_index[1]]<-1-sum(w[positive_index[-1]])
      }
    }
    return(w)
  }
}

# Generate Delaunay Weight Matrix
DWM<-function(Zn,eta=10)
{
  library(Matrix)
  # Data dimension
  n<-nrow(Zn)
  d<-ncol(Zn)
  if((n-1)<=d)
  {
    print("Invalid input.")
  }
  else
  {
    WZ<-Matrix(0,nrow = n,ncol = n)
    mean_Z<-colMeans(Zn)
    Z<-t(t(Zn)-mean_Z)
    r<-max(sqrt(rowSums(Z^2)))*eta
    
    for(i in 1:n)
    {
      central_i<--Z[i,]/(n-1)
      Z_project<-Inverse_Stereographic_projection(Z,central_i,r=r)
      p_project<-Z_project[i,]
      Z_project[i,]<-c(rep(0,d),r)
      S_Zi_Project<-Find_simplex_S(Z_project,p_project)
      if(i%in%S_Zi_Project)
      {
        S_Zi<-S_Zi_Project[S_Zi_Project!=i]
        S_Zi<-S_Zi-(S_Zi>i)
        S_Zi<-Augment_index(Z[-i,],current_index=S_Zi) 
      }else
      {
        S_Zi<-S_Zi_Project
        S_Zi<-S_Zi-(S_Zi>i)
      }
      S_Zi_draw<-S_Zi+(S_Zi>=i)
      
      ww<-Weighting(Z[S_Zi_draw,],Z[i,])
      WZ[i,S_Zi_draw]<-ww
      # print(i)
    }
    
    return(WZ)
  }
}
