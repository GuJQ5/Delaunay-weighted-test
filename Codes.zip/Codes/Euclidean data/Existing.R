kNN_matrix<-function(Z,k)
{
  library(Matrix)
  # Data dimension
  n<-nrow(Z)
  if((((n-1)<=k))!=0)
  {
    print("Invalid input.")
  }
  else
  {
    Dist_k<-matrix(Inf,n,k)
    kNN_index<-matrix(NA,n,k)
    for(i in 1:(n-1))
    {
      for(j in (i+1):n)
      {
        Dist_ij<-sum((Z[i,]-Z[j,])^2)
        Rank_i<-sum(Dist_k[i,]<=Dist_ij)
        if(Rank_i<(k-1))
        {
          Dist_k[i,(Rank_i+1):k]<-c(Dist_ij,Dist_k[i,(Rank_i+1):(k-1)])
          kNN_index[i,(Rank_i+1):k]<-c(j,kNN_index[i,(Rank_i+1):(k-1)])
        }
        else
        {
          if(Rank_i==(k-1))
          {
            Dist_k[i,k]<-Dist_ij
            kNN_index[i,k]<-c(j)
          }
        }
        Rank_j<-sum(Dist_k[j,]<=Dist_ij)
        if(Rank_j<(k-1))
        {
          Dist_k[j,(Rank_j+1):k]<-c(Dist_ij,Dist_k[j,(Rank_j+1):(k-1)])
          kNN_index[j,(Rank_j+1):k]<-c(i,kNN_index[j,(Rank_j+1):(k-1)])
        }
        else
        {
          if(Rank_j==(k-1))
          {
            Dist_k[j,k]<-Dist_ij
            kNN_index[j,k]<-c(i)
          }
        }
      }
    }
    kNN_Adjacency<-Matrix(0,nrow = n,ncol = n)
    for(i in 1:n)
    {
      kNN_Adjacency[i,kNN_index[i,]]<-1:k
    }
    return(kNN_Adjacency)
  }
}

Schilling1986<-function(Z,Delta,k)
{
  # Data dimension
  n<-nrow(Z)
  if((((n-1)<=k)+(n!=length(Delta)))!=0)
  {
    print("Invalid input.")
  }
  else
  {
    kNN_Adjacency<-kNN_matrix(Z,k)
    kNN_Adjacency<-(kNN_Adjacency!=0)
    
    Tkn<-(sum(kNN_Adjacency[Delta==1,Delta==1])+sum(kNN_Adjacency[Delta==0,Delta==0]))/(n*k)
    
    lambda1<-mean(Delta==1)
    lambda0<-mean(Delta==0)
    bar_p1<-n*sum(kNN_Adjacency*t(kNN_Adjacency))/(n*(n-1))/k^2
    p2_count<-0
    for(i in 1:(n-1))
    {
      for(j in (i+1):n)
      {
        p2_count<-p2_count+sum(kNN_Adjacency[i,-c(i,j)]*kNN_Adjacency[j,-c(i,j)])
      }
    }
    bar_p2<-n*p2_count/(n*(n-1)/2)/k^2
    
    mu_k<-lambda1^2+lambda0^2
    sigma2_k<-lambda1*lambda0+4*lambda1^2*lambda0^2*k*bar_p1-lambda1*lambda0*(lambda1-lambda0)^2*k*(1-bar_p2)
    
    T_standard<-sqrt(n*k)*(Tkn-mu_k)/sqrt(sigma2_k)
    pval<-2*(1-pnorm(abs(T_standard)))
    return(pval)
  }
}

Hall2002<-function(Z,Delta,B,k)
{
  # Data dimension
  n<-nrow(Z)
  if((n-1)<=k)
  {
    print("Invalid input.")
  }
  else
  {
    n1<-sum(Delta==1)
    n0<-sum(Delta==0)
    kNN_Adjacency<-kNN_matrix(Z,k)
    
    # test statistic
    M1<-rep(0,n1)
    CDM1<-NULL
    for(j in 1:k)
    {
      M1<-M1+rowSums(kNN_Adjacency[Delta==1,Delta==0]==j)
      CDM1<-c(CDM1,sum(abs(M1-j*n0/(n-1))))
    }
    M0<-rep(0,n0)
    CDM0<-NULL
    for(j in 1:k)
    {
      M0<-M0+rowSums(kNN_Adjacency[Delta==0,Delta==1]==j)
      CDM0<-c(CDM0,sum(abs(M0-j*n1/(n-1))))
    }
    T_obs<-mean(CDM1)+mean(CDM0)
    
    # Permutation Null distribution
    T_null<-NULL
    for(b in 1:B)
    {
      Delta_perm<-Delta[sample(n)]
      # test statistic
      M1<-rep(0,n1)
      CDM1<-NULL
      for(j in 1:k)
      {
        M1<-M1+rowSums(kNN_Adjacency[Delta_perm==1,Delta_perm==0]==j)
        CDM1<-c(CDM1,sum(abs(M1-j*n0/(n-1))))
      }
      M0<-rep(0,n0)
      CDM0<-NULL
      for(j in 1:k)
      {
        M0<-M0+rowSums(kNN_Adjacency[Delta_perm==0,Delta_perm==1]==j)
        CDM0<-c(CDM0,sum(abs(M0-j*n1/(n-1))))
      }
      T_null<-c(T_null,mean(CDM1)+mean(CDM0))
    }
    
    pval<-(1+sum(T_null>T_obs))/(1+B)
    return(pval)
  }
}

Rosenbaum2005<-function(Z,Delta)
{
  n<-nrow(Z)
  library(nbpMatching)
  
  distZ<-distancematrix(as.matrix(dist(Z)))
  Pairing<-nonbimatch(distZ)$halves[,c(1,3)]
  Pairing<-cbind(as.numeric(Pairing[,1]),as.numeric(Pairing[,2]))
  Pairing<-Pairing[rowSums(Pairing>n)==0,]
  Delta_pair<-matrix(Delta[Pairing],ncol = 2)
  n1_fixed<-sum(Delta_pair==1)
  n0_fixed<-sum(Delta_pair==0)
  A1<-sum(rowSums(Delta_pair==1)*rowSums(Delta_pair==0))
  
  E1<-(n0_fixed*n1_fixed)/(n0_fixed+n1_fixed-1)
  V1<-(2*n0_fixed*(n0_fixed-1)*n1_fixed*(n1_fixed-1))/(n0_fixed+n1_fixed-1)^2/(n0_fixed+n1_fixed-3)
  p_value<-2*(1-pnorm(abs(A1-E1)/sqrt(V1)))
  
  return(p_value)
}

Chen2018<-function(Z,Delta,k)
{
  n<-nrow(Z)
  library(ape)
  
  distZ<-as.matrix(dist(Z))
  kMST_Adjacency<-Matrix(0,nrow = n,ncol = n)
  for(i in 1:k)
  {
    mst_i<-ape::mst(distZ)
    Ai<-which(mst_i==1)
    row_index<-(Ai-1)%%n+1
    col_index<-ceiling(Ai/n)
    for(a in 1:length(row_index))
    {
      kMST_Adjacency[row_index[a],col_index[a]]<-1
      distZ[row_index[a],col_index[a]]<-Inf
    }
  }
  lambda1<-mean(Delta==1)
  lambda0<-mean(Delta==0)
  n1<-sum(Delta==1)
  n0<-sum(Delta==0)
  R1<-sum(kMST_Adjacency[Delta==1,Delta==1])/2
  R0<-sum(kMST_Adjacency[Delta==0,Delta==0])/2
  Rw<-lambda1*R1+lambda0*R0
  
  G_size<-sum(kMST_Adjacency)/2
  E1<-G_size*(n1*(n1-1))/(n*(n-1))
  E0<-G_size*(n0*(n0-1))/(n*(n-1))
  ERw<-lambda1*E1+lambda0*E0
  
  G_i<-rowSums(kMST_Adjacency)
  Constant<-sum(G_i^2)-4*G_size^2/n
  DD<-(n*n0*n1-2*n1^2-2*n0^2+2*n1*n0)/(n^2*(n1-1)*(n0-1))
  DDout<-(n0*(n0-1)*n1*(n1-1))/(prod(n-(0:3)))
  VRw<-DDout*(G_size-DD*Constant-2/(n*(n-1))*G_size^2)
  
  T_standard<-(Rw-ERw)/sqrt(VRw)
  pval<-2*(1-pnorm(abs(T_standard)))
  
  return(pval)
}

Chen2017<-function(Z,Delta,k)
{
  n<-nrow(Z)
  library(ape)
  
  distZ<-as.matrix(dist(Z))
  kMST_Adjacency<-Matrix(0,nrow = n,ncol = n)
  for(i in 1:k)
  {
    mst_i<-ape::mst(distZ)
    Ai<-which(mst_i==1)
    row_index<-(Ai-1)%%n+1
    col_index<-ceiling(Ai/n)
    for(a in 1:length(row_index))
    {
      kMST_Adjacency[row_index[a],col_index[a]]<-1
      distZ[row_index[a],col_index[a]]<-Inf
    }
  }
  R1<-sum(kMST_Adjacency[Delta==1,Delta==1])/2
  R0<-sum(kMST_Adjacency[Delta==0,Delta==0])/2
  
  n1<-sum(Delta==1)
  n0<-sum(Delta==0)
  G_size<-sum(kMST_Adjacency)/2
  G_i<-rowSums(kMST_Adjacency)
  Constant<-sum(G_i^2)/2-G_size
  
  E1<-G_size*(n1*(n1-1))/(n*(n-1))
  E0<-G_size*(n0*(n0-1))/(n*(n-1))
  V11<-E1*(1-E1)+2*Constant*(n1*(n1-1)*(n1-2))/(n*(n-1)*(n-2))+(G_size^2-G_size-2*Constant)*(n1*(n1-1)*(n1-2)*(n1-3))/(n*(n-1)*(n-2)*(n-3))
  V00<-E0*(1-E0)+2*Constant*(n0*(n0-1)*(n0-2))/(n*(n-1)*(n-2))+(G_size^2-G_size-2*Constant)*(n0*(n0-1)*(n0-2)*(n0-3))/(n*(n-1)*(n-2)*(n-3))
  V10<-(G_size^2-G_size-2*Constant)*(n0*(n0-1)*n1*(n1-1))/(n*(n-1)*(n-2)*(n-3))-E1*E0
  
  VVV<-matrix(c(V11,V10,V10,V00),nrow = 2)
  
  
  T_standard<-(t(c(R1-E1,R0-E0))%*%solve(VVV)%*%c(R1-E1,R0-E0))[1,1]
  pval<-(1-pchisq(T_standard,df=2))
  
  return(pval)
}

Cheng2021<-function(Z,Delta,B,bw)
{
  # Data dimension
  n<-nrow(Z)
  
  n1<-sum(Delta==1)
  n0<-sum(Delta==0)
  dist_Z<-as.matrix(dist(Z))
  Kernel_matrix<-exp(-dist_Z^2/bw^2)
  
  # test statistic
  T_obs<-mean(Kernel_matrix[Delta==0,Delta==0])+mean(Kernel_matrix[Delta==1,Delta==1])-2*mean(Kernel_matrix[Delta==1,Delta==0])
  
  # Permutation Null distribution
  T_null<-NULL
  for(b in 1:B)
  {
    Delta_perm<-Delta[sample(n)]
    # test statistic
    
    T_null<-c(T_null,mean(Kernel_matrix[Delta_perm==0,Delta_perm==0])+mean(Kernel_matrix[Delta_perm==1,Delta_perm==1])-2*mean(Kernel_matrix[Delta_perm==1,Delta_perm==0]))
  }
  
  pval<-(1+sum(T_null>T_obs))/(1+B)
  return(pval)
}

Cai2013<-function(Z,Delta)
{
  # Data dimension
  n<-nrow(Z)
  d<-ncol(Z)
  
  n1<-sum(Delta==1)
  n0<-sum(Delta==0)
  
  Z_1<-Z[Delta==1,]
  Z_0<-Z[Delta==0,]
  
  Sigma_1<-(t(Z_1)%*%Z_1)/n1
  Sigma_0<-(t(Z_0)%*%Z_0)/n0
  
  Theta_1<-(t(Z_1^2)%*%(Z_1^2))/n1-Sigma_1^2
  Theta_0<-(t(Z_0^2)%*%(Z_0^2))/n0-Sigma_0^2
  
  M_10<-(Sigma_1-Sigma_0)^2/(Theta_1/n1+Theta_0/n0+((Theta_1/n1+Theta_0/n0)==0))
  M_n<-max(M_10)
  Test_stat<-M_n-4*log(d)+log(log(d))
  
  
  pval<-1-exp(-exp(-Test_stat/2)/sqrt(8*pi))
  return(pval)
}

Kim2019<-function(Z,Delta,B,ntree=500,mtry=floor(sqrt(ncol(Z))))
{
  n<-nrow(Z)
  d<-ncol(Z)
  
  n1<-sum(Delta==1)
  n0<-sum(Delta==0)
  
  RF_obs<-randomForest(Z,as.factor(Delta),ntree = ntree,mtry=mtry)
  T_obs<-mean((RF_obs$votes[,1]-n1/n)^2)
  
  # Permutation Null distribution
  T_null<-NULL
  for(b in 1:B)
  {
    Delta_perm<-Delta[sample(n)]
    # test statistic
    RF_perm<-randomForest(Z,as.factor(Delta_perm),ntree = ntree,mtry=mtry)
    T_perm<-mean((RF_perm$votes[,1]-n1/n)^2)
    T_null<-c(T_null,T_perm)
    # print(b)
  }
  
  pval<-(1+sum(T_null>T_obs))/(1+B)
  return(pval)
}

Szekely2004<-function(Z,Delta,B)
{
  # Data dimension
  n<-nrow(Z)
  
  n1<-sum(Delta==1)
  n0<-sum(Delta==0)
  dist_Z<-as.matrix(dist(Z))
  # Kernel_matrix<-exp(-dist_Z^2/bw^2)
  
  # test statistic
  T_obs<-mean(dist_Z[Delta==0,Delta==0])+mean(dist_Z[Delta==1,Delta==1])-2*mean(dist_Z[Delta==1,Delta==0])
  
  # Permutation Null distribution
  T_null<-NULL
  for(b in 1:B)
  {
    Delta_perm<-Delta[sample(n)]
    # test statistic
    
    T_null<-c(T_null,mean(dist_Z[Delta_perm==0,Delta_perm==0])+mean(dist_Z[Delta_perm==1,Delta_perm==1])-2*mean(dist_Z[Delta_perm==1,Delta_perm==0]))
  }
  
  pval<-(1+sum(T_null<T_obs))/(1+B)
  return(pval)
}

Kim2019_new<-function(Z,Delta,B,k)
{
  n<-nrow(Z)
  d<-ncol(Z)
  
  n1<-sum(Delta==1)
  n0<-sum(Delta==0)
  
  kNN_Adjacency<-kNN_matrix(Z,k)
  kNN_Adjacency<-(kNN_Adjacency!=0)
  
  RF_obs_votes<-rowSums(kNN_Adjacency[,Delta==1])/k
  T_obs<-mean((RF_obs_votes-n1/n)^2)
  
  
  T_null<-NULL
  for(b in 1:B)
  {
    Delta_perm<-Delta[sample(n)]
    # test statistic
    RF_perm_votes<-rowSums(kNN_Adjacency[,Delta_perm==1])/k
    T_perm<-mean((RF_perm_votes-n1/n)^2)
    T_null<-c(T_null,T_perm)
    # print(b)
  }
  pval<-(1+sum(T_null>T_obs))/(1+B)
  return(pval)
}