kNN_matrix<-function(Z,k)
{
  library(Matrix)
  # Data dimension
  n<-nrow(Z)
  if((((n-1)<=k))!=0)
  {
    print("Invalid input.")
  }
  else
  {
    Dist_k<-matrix(Inf,n,k)
    kNN_index<-matrix(NA,n,k)
    for(i in 1:(n-1))
    {
      for(j in (i+1):n)
      {
        Dist_ij<-sum((Z[i,]-Z[j,])^2)
        Rank_i<-sum(Dist_k[i,]<=Dist_ij)
        if(Rank_i<(k-1))
        {
          Dist_k[i,(Rank_i+1):k]<-c(Dist_ij,Dist_k[i,(Rank_i+1):(k-1)])
          kNN_index[i,(Rank_i+1):k]<-c(j,kNN_index[i,(Rank_i+1):(k-1)])
        }
        else
        {
          if(Rank_i==(k-1))
          {
            Dist_k[i,k]<-Dist_ij
            kNN_index[i,k]<-c(j)
          }
        }
        Rank_j<-sum(Dist_k[j,]<=Dist_ij)
        if(Rank_j<(k-1))
        {
          Dist_k[j,(Rank_j+1):k]<-c(Dist_ij,Dist_k[j,(Rank_j+1):(k-1)])
          kNN_index[j,(Rank_j+1):k]<-c(i,kNN_index[j,(Rank_j+1):(k-1)])
        }
        else
        {
          if(Rank_j==(k-1))
          {
            Dist_k[j,k]<-Dist_ij
            kNN_index[j,k]<-c(i)
          }
        }
      }
    }
    kNN_Adjacency<-Matrix(0,nrow = n,ncol = n)
    for(i in 1:n)
    {
      kNN_Adjacency[i,kNN_index[i,]]<-1:k
    }
    return(kNN_Adjacency)
  }
}

Intrinsic_dimension_estimate<-function(Z)
{
  n<-nrow(Z)
  Z2<-kNN_matrix(Z,2)
  mu_i<-NULL
  for(i in 1:n)
  {
    index1<-which(Z2[i,]==1)
    index2<-which(Z2[i,]==2)
    
    l1<-sqrt(sum((Z[i,]-Z[index1,])^2))
    l2<-sqrt(sum((Z[i,]-Z[index2,])^2))
    
    mu_i<-c(mu_i,l2/l1)
  }
  
  mu_i<-sort(mu_i)
  Surv_i<-1-(1:n)/n
  mu_i<-mu_i[Surv_i>=0.1]
  Surv_i<-Surv_i[Surv_i>=0.1]
  
  lm_mu<-lm(-log(Surv_i)~log(mu_i)-1)
  d_hat<-round(lm_mu$coefficients)
  
  return(d_hat)
}

{
# Robust_geodesic_distance<-function(Z)
# {
#   n<-nrow(Z)
#   
#   library(ape)
#   library(igraph)
#   distZ<-as.matrix(dist(Z))
#   mst_i<-ape::mst(distZ)
#   Ai<-which(mst_i==1)
#   row_index<-(Ai-1)%%n+1
#   col_index<-ceiling(Ai/n)
#   wa<-which(row_index<col_index)
#   row_index<-row_index[wa]
#   col_index<-col_index[wa]
#   epsilon<-rep(0,n)
#   for(a in 1:length(row_index))
#   {
#     da<-distZ[row_index[a],col_index[a]]
#     epsilon[row_index[a]]<-max(c(epsilon[row_index[a]],da))
#     epsilon[col_index[a]]<-max(c(epsilon[col_index[a]],da))
#   }
#   resolution<-100:0/100
#   edge_set<-NULL
#   length_set<-NULL
#   for(a in 1:(n-1))
#   {
#     for(b in (a+1):n)
#     {
#       path_ab<-resolution%*%t(Z[a,])+(1-resolution)%*%t(Z[b,])
#       dist_bijiao<-rowSums(Z^2)%*%t(rep(1,length(resolution)))+rep(1,n)%*%t(rowSums(path_ab^2))-2*Z%*%t(path_ab)
#       dist_bijiao<-dist_bijiao-epsilon^2
#       jieguo<-prod(colSums(dist_bijiao<0)>=1)
#       if(jieguo==1)
#       {
#         edge_set<-rbind(edge_set,c(a,b))
#         length_set<-c(length_set,distZ[a,b])
#       }
#       # print(c(a,b))
#     }
#   }
#   robust_graph<-make_graph(as.vector(t(edge_set)),directed = F)
#   # edge.attributes(robust_graph)$weight<-length_set
#   dist_ZM<-distances(robust_graph, mode  ="all",weights = length_set)
#   
#   return(dist_ZM)
# }
# 
# Robust_geodesic_distance_fix<-function(Z)
# {
#   n<-nrow(Z)
#   
#   library(ape)
#   library(igraph)
#   distZ<-as.matrix(dist(Z))
#   mst_i<-ape::mst(distZ)
#   Ai<-which(mst_i==1)
#   row_index<-(Ai-1)%%n+1
#   col_index<-ceiling(Ai/n)
#   wa<-which(row_index<col_index)
#   row_index<-row_index[wa]
#   col_index<-col_index[wa]
#   epsilon<-rep(0,n)
#   for(a in 1:length(row_index))
#   {
#     da<-distZ[row_index[a],col_index[a]]
#     epsilon[row_index[a]]<-max(c(epsilon[row_index[a]],da))
#     epsilon[col_index[a]]<-max(c(epsilon[col_index[a]],da))
#   }
#   epsilon<-epsilon*0.75
#   resolution<-100:0/100
#   edge_set<-NULL
#   length_set<-NULL
#   for(a in 1:(n-1))
#   {
#     for(b in (a+1):n)
#     {
#       Ye<-(Z%*%(Z[a,]-Z[b,]))[,1]
#       lambda_min<-(Ye-Ye[b])/distZ[a,b]^2
#       Projections<-cbind(lambda_min,1-lambda_min)%*%Z[c(a,b),]
#       dist_min<-sqrt(rowSums((Z-Projections)^2))
#       Xuan<-which(dist_min<=epsilon)
#       interval_half_length<-sqrt(epsilon[Xuan]^2-dist_min[Xuan]^2)
#       intervals<-cbind(lambda_min[Xuan]-interval_half_length/distZ[a,b],lambda_min[Xuan]+interval_half_length/distZ[a,b])
#       
#       now<-0
#       In_or_out<-((intervals[,1]<=now)&(intervals[,2]>now))
#       while((max(In_or_out)==1)&(now<1))
#       {
#         now<-max(intervals[In_or_out,2])
#         In_or_out<-((intervals[,1]<=now)&(intervals[,2]>now))
#       }
#       if(now>=1)
#       {
#         edge_set<-rbind(edge_set,c(a,b))
#         length_set<-c(length_set,distZ[a,b])
#       }
#       # print(c(a,b))
#     }
#   }
#   robust_graph<-make_graph(as.vector(t(edge_set)),directed = F)
#   # edge.attributes(robust_graph)$weight<-length_set
#   dist_ZM<-distances(robust_graph, mode  ="all",weights = length_set)
#   
#   return(dist_ZM)
# }
}

Robust_geodesic_distance<-function(Z,k)
{
  n<-nrow(Z)
  
  library(ape)
  library(igraph)
  distZ<-as.matrix(dist(Z))
  mst_i<-ape::mst(distZ)
  ZkNN<-kNN_matrix(Z,k+1)
  mst_i<-ZkNN+(ZkNN>0)-mst_i
  mst_i<-mst_i*(mst_i<=(k+1))
  Ai<-(mst_i!=0)
  edge_index<-(which(Ai==1))
  row_index<-(edge_index-1)%%n+1
  col_index<-ceiling(edge_index/n)
  wa<-which(row_index<col_index)
  row_index<-row_index[wa]
  col_index<-col_index[wa]
  length_set<-distZ[edge_index[wa]]
  edge_set<-rbind(row_index,col_index)
  # Checkpoint
  robust_graph<-make_graph(as.vector((edge_set)),directed = F)
  # edge.attributes(robust_graph)$weight<-length_set
  dist_ZM<-distances(robust_graph, mode  ="all",weights = length_set)
  
  return(dist_ZM)
}