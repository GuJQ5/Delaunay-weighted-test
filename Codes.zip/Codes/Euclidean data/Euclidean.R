args = commandArgs(TRUE)
Pai = as.numeric(args[1])
Pai_a<-ceiling(Pai/30)
Pai<-Pai-(Pai_a-1)*30
Pai_b<-ceiling(Pai/5)
Pai_c<-Pai-(Pai_b-1)*5

library(mvtnorm)
source("/home/j/jiaqigu/DW/Euclidean/Existing.R")
source("/home/j/jiaqigu/DW/Euclidean/Function.R")
# source("Existing.R")
# source("Function.R")

Setting<-c("Null","Location","Direction")[Pai_a]
n1<-c(50,100,100,50,100,100)[Pai_b]
n0<-c(50,50,100,50,50,100)[Pai_b]
d<-c(20,20,20,50,50,50)[Pai_b]
B<-1000
n<-n1+n0
n_iter<-200
##############################################
P_value_record<-NULL
kai<-0
# P_value_record<-as.matrix(read.csv(paste0("/home/j/jiaqigu/DW/Euclidean/",Setting,"_",Pai_b,"_",Pai_c,".csv")))
# kai<-(nrow(P_value_record))
if(kai<n_iter)
{
  for(iter in (kai+1):n_iter)
  {
  TT0<-Sys.time()
  mu<-rnorm(d)
  mu<-mu/sqrt(sum(mu^2))*(0.8+0.2*(d==50))*(Pai_a==2)
  X<-rmvnorm(n1,rep(0,d))
  Y<-rmvnorm(n0,mu)
  
  X[,1:(d/2)]<-X[,1:(d/2)]*(1+0.25*(Pai_a==3))
  Y[,(d/2)+(1:(d/2))]<-Y[,(d/2)+(1:(d/2))]*(1+0.25*(Pai_a==3))
  
  Z<-rbind(X,Y)
  Delta<-c(rep(1,n1),rep(0,n0))
  
  WZ2<-DWM(Z,eta=15)
  
  T1<-sum(WZ2[Delta==1,Delta==1])+sum(WZ2[Delta==0,Delta==0])
  T1_perm<-NULL
  for(b in 1:B)
  {
    Delta_perm<-Delta[sample(n)]
    
    T1_perm<-c(T1_perm,sum(WZ2[Delta_perm==1,Delta_perm==1])+sum(WZ2[Delta_perm==0,Delta_perm==0]))
  }
  P_DW<-(1+sum(T1_perm>=T1))/(1+B)
  
  bw<-sqrt(sum(apply(Z,2,var)))*n^(-1/(d+2))
  P_kNN<-Hall2002(Z,Delta,B=B,k=d+1)
  P_kMST<-Chen2017(Z,Delta,k=d+1)
  P_kernel<-Cheng2021(Z,Delta,B=B,bw=bw)
  P_euclidean<-Szekely2004(Z,Delta,B=B)
  P_cov<-Cai2013(Z,Delta)
  k_xuan<-ceiling(5*n^(2/(2+d)))
  P_regression<-Kim2019_new(Z,Delta,B=B,k=k_xuan)
  P_value_record<-rbind(P_value_record,c(P_DW,P_kNN,P_kMST,P_kernel,P_euclidean,P_cov,P_regression))
  
  TT1<-Sys.time()
  print(paste0("Setting:",Setting,",d=",d,",n1=",n1,",n0=",n0,",file=",Pai_c,",iteration=",iter))
  print(TT1-TT0)
  # if(iter%%10==0)
  # {
  write.csv(P_value_record,paste0("/home/j/jiaqigu/DW/Euclidean/",Setting,"_",Pai_b,"_",Pai_c,".csv"),row.names = F)
  # }
  }
}